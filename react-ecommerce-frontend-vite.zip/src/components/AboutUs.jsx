import React from 'react';

const AboutUs = () => (
  <div style={{ padding: '20px' }}>
    <h2>About Us</h2>
    <p>This is a sample e-commerce platform built with React and Node.js.</p>
  </div>
);

export default AboutUs;
