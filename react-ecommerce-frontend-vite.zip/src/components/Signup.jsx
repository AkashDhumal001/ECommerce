import React, { useState } from 'react';
import api from '../api';

const Signup = () => {
  const [form, setForm] = useState({ name: '', phone: '', email: '', password: '' });
  const [message, setMessage] = useState('');

  const validate = () => {
    const { name, phone, email, password } = form;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^[0-9]{10}$/;
    const passwordRegex = /^.{6,}$/;

    if (!name || !phone || !email || !password) return 'All fields required';
    if (!emailRegex.test(email)) return 'Invalid email';
    if (!phoneRegex.test(phone)) return 'Phone must be 10 digits';
    if (!passwordRegex.test(password)) return 'Password must be at least 6 characters';

    return '';
  };

  const handleSignup = async (e) => {
    e.preventDefault();
    const error = validate();
    if (error) return setMessage(error);

    try {
      await api.post('/auth/signup', form);
      setMessage('User registered successfully');
    } catch (err) {
      setMessage('Signup failed');
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Signup</h2>
      <form onSubmit={handleSignup}>
        <input placeholder="Name" onChange={(e) => setForm({ ...form, name: e.target.value })} required /><br />
        <input placeholder="Phone" onChange={(e) => setForm({ ...form, phone: e.target.value })} required /><br />
        <input placeholder="Email" onChange={(e) => setForm({ ...form, email: e.target.value })} required /><br />
        <input type="password" placeholder="Password" onChange={(e) => setForm({ ...form, password: e.target.value })} required /><br />
        <button type="submit">Signup</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
};

export default Signup;
