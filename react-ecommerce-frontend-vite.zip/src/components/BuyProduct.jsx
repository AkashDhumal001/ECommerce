import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api';

const BuyProduct = () => {
  const { productId } = useParams();
  const [quantity, setQuantity] = useState(1);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleBuy = async () => {
    try {
      await api.post('/buy', { productId, quantity });
      setMessage('Order placed successfully');
      setTimeout(() => navigate('/products'), 1000);
    } catch (err) {
      setMessage('Failed to place order');
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Buy Product</h2>
      <p>Product ID: {productId}</p>
      <input
        type="number"
        min="1"
        value={quantity}
        onChange={(e) => setQuantity(e.target.value)}
      />
      <button onClick={handleBuy}>Place Order</button>
      {message && <p>{message}</p>}
    </div>
  );
};

export default BuyProduct;
