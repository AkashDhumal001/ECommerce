import React from 'react';

const Home = () => (
  <div style={{ padding: '20px' }}>
    <h1>Welcome to Our E-commerce Store</h1>
    <p>Browse and buy your favorite products online!</p>
  </div>
);

export default Home;
