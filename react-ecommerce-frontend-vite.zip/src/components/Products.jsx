import React, { useEffect, useState } from 'react';
import api from '../api';
import { Link } from 'react-router-dom';

const Products = () => {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    fetchProducts();
  }, [search, category, page]);

  const fetchProducts = async () => {
    try {
      const res = await api.get('/products', {
        params: { search, category, page }
      });
      setProducts(res.data.products);
      setTotalPages(res.data.totalPages);
    } catch (err) {
      console.error('Failed to fetch products');
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Products</h2>
      <input placeholder="Search" value={search} onChange={(e) => setSearch(e.target.value)} />
      <input placeholder="Category" value={category} onChange={(e) => setCategory(e.target.value)} />
      <div>
        {products.map(product => (
          <div key={product.id} style={{ borderBottom: '1px solid #ccc', padding: '10px' }}>
            <h3>{product.name}</h3>
            <p>Price: ₹{product.price}</p>
            <p>Category: {product.category}</p>
            <Link to={`/buy/${product.id}`}>Buy</Link>
          </div>
        ))}
      </div>
      <div style={{ marginTop: '10px' }}>
        <button onClick={() => setPage(prev => Math.max(1, prev - 1))}>Previous</button>
        <span style={{ margin: '0 10px' }}>Page {page} of {totalPages}</span>
        <button onClick={() => setPage(prev => (prev < totalPages ? prev + 1 : prev))}>Next</button>
      </div>
    </div>
  );
};

export default Products;
