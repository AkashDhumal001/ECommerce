import React from 'react';

const ContactUs = () => (
  <div style={{ padding: '20px' }}>
    <h2>Contact Us</h2>
    <p>Email: support@example.com</p>
    <p>Phone: +91-1234567890</p>
  </div>
);

export default ContactUs;
